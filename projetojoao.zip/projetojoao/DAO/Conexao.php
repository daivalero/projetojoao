<?php
namespace PHP\Modelo\DAO;

class Conexao {
    public function conectar() {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "ferramentas";

        // Cria a conexão sem o namespace PHP\Modelo\DAO
        $conn = new \mysqli($servername, $username, $password, $dbname);

        // Checa a conexão
        if ($conn->connect_error) {
            die("Falha na conexão com o banco de dados: " . $conn->connect_error);
        }
        return $conn;
    }
}
?>
