<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Cadastrar Ferramenta</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
      padding: 0;
      background: #f1f2f6;
    }

    .container {
      max-width: 1000px;
      margin: auto;
      background: white;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
      margin-top: 50px;
    }

    h2 {
      text-align: center;
      margin-bottom: 30px;
      color: #333;
    }

    .tool-block {
      border-left: 5px solid #007bff;
      background-color: #f9f9f9;
      padding: 20px;
      margin-bottom: 25px;
      border-radius: 8px;
      box-shadow: 0 2px 5px rgba(0,0,0,0.05);
    }

    label {
      font-family: 'Segoe UI', sans-serif;
      display: block;
      margin: 10px 0 5px;
    }

    .tool-block input[type="text"] {
      font-size: 16px;
      padding: 8px;
      width: 100%;
      margin-bottom: 10px;
      border-radius: 6px;
      border: 1px solid #ccc;
    }

    .question {
      font-weight: 600;
      margin-top: 20px;
      margin-bottom: 5px;
      color: #333;
    }

    .scale-container {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      margin-bottom: 15px;
    }

    .scale-container label {
      display: flex;
      align-items: center;
      justify-content: center;
      background: #e0e0e0;
      padding: 8px 12px;
      border-radius: 5px;
      font-size: 14px;
      cursor: pointer;
      transition: 0.2s;
      width: 40px;
      height: 40px;
      text-align: center;
      user-select: none;
      position: relative;
      margin: 5px;
      border: 2px solid #e0e0e0;
    }

    .scale-container input {
      display: none;
    }

    .scale-container span {
      display: inline-block;
      width: 100%;
      height: 100%;
      line-height: 30px;
    }

    .scale-container input:checked + span {
      border: 2px solid #007bff;
      color: inherit;
      font-weight: inherit;
    }

    .status-options label {
      margin-right: 20px;
      font-weight: 500;
    }

    button[type="submit"], .back-button {
      display: inline-block;
      padding: 12px 30px;
      font-size: 16px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      text-align: center;
      transition: 0.3s;
    }

    button[type="submit"] {
      background-color: #007bff;
      color: white;
    }

    button[type="submit"]:hover {
      background-color: #0056b3;
    }

    .back-button {
      background-color: #007bff;
      color: white;
      text-decoration: none;
    }

    .back-button:hover {
      background-color: #0056b3;
    }

    .button-container {
      display: flex;
      justify-content: flex-end;
      gap: 10px; /* Reduzi o espaçamento entre os botões */
      margin-top: 20px;
    }

    .back-button {
      margin-right: auto; /* Faz o botão "Voltar" ficar à esquerda */
    }
  </style>
</head>
<body>

<div class="container">
  <h2>Cadastrar Ferramenta</h2>
  
  <form action="cadastrar.php" method="POST">
    <div class="tool-block">
      <label for="nome_ferramenta">Nome da Ferramenta:</label>
      <input type="text" name="nome_ferramenta" id="nome_ferramenta">

      <div class="question">1. A ferramenta está funcionando durante o uso?</div>
      <div class="scale-container">
        <label><input type="radio" name="afiacao" value="1"><span>1</span></label>
        <label><input type="radio" name="afiacao" value="2"><span>2</span></label>
        <label><input type="radio" name="afiacao" value="3"><span>3</span></label>
        <label><input type="radio" name="afiacao" value="4"><span>4</span></label>
        <label><input type="radio" name="afiacao" value="5"><span>5</span></label>
        <label><input type="radio" name="afiacao" value="6"><span>6</span></label>
        <label><input type="radio" name="afiacao" value="7"><span>7</span></label>
        <label><input type="radio" name="afiacao" value="8"><span>8</span></label>
        <label><input type="radio" name="afiacao" value="9"><span>9</span></label>
        <label><input type="radio" name="afiacao" value="10"><span>10</span></label>
      </div>

      <div class="question">2. Apresenta sinais visíveis de desgaste, ferrugem ou danos estruturais?</div>
      <div class="scale-container">
        <label><input type="radio" name="estado_uso" value="1"><span>1</span></label>
        <label><input type="radio" name="estado_uso" value="2"><span>2</span></label>
        <label><input type="radio" name="estado_uso" value="3"><span>3</span></label>
        <label><input type="radio" name="estado_uso" value="4"><span>4</span></label>
        <label><input type="radio" name="estado_uso" value="5"><span>5</span></label>
        <label><input type="radio" name="estado_uso" value="6"><span>6</span></label>
        <label><input type="radio" name="estado_uso" value="7"><span>7</span></label>
        <label><input type="radio" name="estado_uso" value="8"><span>8</span></label>
        <label><input type="radio" name="estado_uso" value="9"><span>9</span></label>
        <label><input type="radio" name="estado_uso" value="10"><span>10</span></label>
      </div>

      <div class="status-options">
        <label>Status:</label><br>
        <label><input type="radio" name="status" value="Utilizável"> Utilizável</label>
        <label><input type="radio" name="status" value="Manutenção"> Manutenção</label>
        <label><input type="radio" name="status" value="Descarte"> Descarte</label>
      </div>
    </div>

    <div class="button-container">
      <a href="index.html" class="back-button">Voltar</a>
      <button type="submit">Salvar</button>
    </div>
  </form>
</div>

</body>
</html>
