<?php
namespace PHP\Modelo;

require_once('../DAO/Conexao.php');
use PHP\Modelo\DAO\Conexao;

$msg = ""; // <- EVITA o aviso de variável indefinida

$conn = (new Conexao())->conectar();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nome = $_POST['nome'] ?? '';
    $matricula = $_POST['matricula'] ?? '';
    $senha = $_POST['senha'] ?? '';

    $login = strtolower(substr($nome, 0, 1)) . $matricula;
    $senhaCriptografada = password_hash($senha, PASSWORD_DEFAULT);

    $sql = "INSERT INTO usuarios (nome, matricula, login, senha) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $nome, $matricula, $login, $senhaCriptografada);

    if ($stmt->execute()) {
        $msg = "Usuário cadastrado com sucesso! Login: $login";
    } else {
        $msg = "Erro ao cadastrar: " . $conn->error;
    }

    $stmt->close();
    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Cadastrar Usuário</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f1f2f6;
      margin: 0;
      padding: 0;
    }

    .container {
      max-width: 400px;
      margin: 80px auto;
      background: white;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      color: #333;
      margin-bottom: 30px;
    }

    label {
      display: block;
      margin: 10px 0 5px;
    }

    input[type="text"], input[type="password"] {
      width: 100%;
      padding: 10px;
      border-radius: 6px;
      border: 1px solid #ccc;
      font-size: 16px;
    }

    button {
      margin-top: 20px;
      width: 100%;
      padding: 12px;
      background-color: #007bff;
      border: none;
      color: white;
      font-size: 16px;
      border-radius: 8px;
      cursor: pointer;
    }

    button:hover {
      background-color: #0056b3;
    }

    .mensagem {
      color: green;
      text-align: center;
      margin-top: 10px;
    }

    .back-link {
      text-align: center;
      display: block;
      margin-top: 15px;
      text-decoration: none;
      color: #007bff;
    }

    .back-link:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

<div class="container">
  <h2>Cadastrar Usuário</h2>
  <form method="POST">
    <label for="nome">Nome Completo:</label>
    <input type="text" name="nome" id="nome">

    <label for="matricula">Matrícula:</label>
    <input type="text" name="matricula" id="matricula">

    <label for="senha">Senha:</label>
    <input type="password" name="senha" id="senha">

    <button type="submit">Cadastrar</button>
    <a href="login.php" class="back-link">Voltar para o login</a>
  </form>

  <?php if ($msg): ?>
    <div class="mensagem"><?= $msg ?></div>
  <?php endif; ?>
</div>

</body>
</html>
