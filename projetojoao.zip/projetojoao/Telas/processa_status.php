<?php
namespace PHP\Modelo;

require_once('../DAO/Conexao.php');
use PHP\Modelo\DAO\Conexao;

// Função para determinar o status
function determinarStatus($afiacao, $estado_uso) {
    if ($afiacao == 0 && $estado_uso == 0) {
        return 'Descarte';
    } elseif ($afiacao > 50 && $estado_uso < 50) {
        return 'Manutenção';
    } elseif ($afiacao > 50 && $estado_uso > 50) {
        return 'Utilizável';
    }
    return 'Indeterminado'; // Caso o critério não se encaixe em nenhum dos anteriores
}

// Estabelece a conexão com o banco de dados
$conn = (new Conexao())->conectar();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Verifica se o status foi enviado
    if (isset($_POST['status'])) {
        foreach ($_POST['status'] as $ferramenta_id => $status) {
            // Exemplo de valores para afiacao e estado_uso (em um cenário real, você deve obter esses dados do banco)
            $afiacao = 60;  // Aqui você deveria pegar o valor real do banco de dados
            $estado_uso = 70; // Aqui você também deveria pegar o valor real do banco de dados
            
            // Determina o status da ferramenta
            $status_final = determinarStatus($afiacao, $estado_uso);
            
            // Atualiza o status da ferramenta no banco de dados
            $updateQuery = "UPDATE ferramenta SET status = ? WHERE id_ferramenta = ?";
            if ($stmt = $conn->prepare($updateQuery)) {
                $stmt->bind_param("si", $status_final, $ferramenta_id);
                $stmt->execute();
                $stmt->close();
                echo "Ferramenta ID: $ferramenta_id - Status: $status_final foi atualizado.<br>";
            } else {
                echo "Erro ao preparar a consulta SQL: " . $conn->error;
            }
        }
    } else {
        echo "Nenhum status foi selecionado.";
    }
}

// Fecha a conexão
$conn->close();
?>
