<?php
namespace PHP\Modelo;

require_once('../DAO/Conexao.php');

use PHP\Modelo\DAO\Conexao;

$msg = "";
$conn = (new Conexao())->conectar();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nome = $_POST['nome'] ?? '';
    $matricula = $_POST['matricula'] ?? '';
    $senha = $_POST['senha'] ?? '';

    $login = strtolower(substr($nome, 0, 1)) . $matricula;
    $senhaCriptografada = password_hash($senha, PASSWORD_DEFAULT);

    $sql = "INSERT INTO usuarios (nome, matricula, login, senha) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $nome, $matricula, $login, $senhaCriptografada);

    if ($stmt->execute()) {
        $msg = "Usuário cadastrado com sucesso! Login: $login";
    } else {
        $msg = "Erro ao cadastrar: " . $conn->error;
    }

    $stmt->close();
    $conn->close();
}
?>
